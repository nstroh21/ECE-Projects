public abstract class AbstractProgram3 {

    public abstract TownPlan findOptimalResponseTime(TownPlan town);

    public abstract TownPlan findOptimalPoliceStationPositions(TownPlan town);
}
