public abstract class AbstractProgram1 {
    public abstract boolean isStableMatching(Matching problem);

    public abstract Matching stableMatchingGaleShapley_highschooloptimal(Matching problem);

    public abstract Matching stableMatchingGaleShapley_studentoptimal(Matching problem);
}